RetailMax: глава 4, C4 и UML As-Is.
Откройте 04_e-commerce_domain/output/RetailMax_chapter4_AsIs.html или PDF в output/pdf.
PlantUML и SVG: 04_e-commerce_domain/06_Architecture_Models/C4, UML и ArchiMate.
Описание и допущения: 04_e-commerce_domain/02_Application_Architecture/APP-EC-001-as-is.md.
Файлы исходного кейса и BPMN включены для работы относительных ссылок.
